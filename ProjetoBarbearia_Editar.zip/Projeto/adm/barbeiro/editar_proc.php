<?php
require_once("bd.php");
$idbarbeiro = intval (filter_input(INPUT_POST,'IDBARBEIRO',FILTER_DEFAULT));
$Nome = filter_input(INPUT_POST,'NOME',FILTER_DEFAULT);
$CPF = filter_input(INPUT_POST,'CPF',FILTER_DEFAULT);
$Especializacao = filter_input(INPUT_POST,'ESPECIALIZACAO',FILTER_DEFAULT);
/*esses campos vão mudar, lembre-se*/
$sql = "UPDATE BARBEIRO (NOME,ESPECIALIZACAO,CPF)
        VALUES (?,?,? ) 
        WHERE IDBARBEIRO=? ";        

$rs = mysqli_prepare($banco,$sql);
                                            
mysqli_stmt_bind_param($rs,'sss', $Nome ,$CPF, $Especializacao) ;                                            
mysqli_stmt_execute($rs);
header('location:index.php');
