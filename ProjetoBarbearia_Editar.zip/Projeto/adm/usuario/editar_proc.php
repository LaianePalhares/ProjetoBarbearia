<?php
require_once("bd.php");
$idusuario = intval (filter_input(INPUT_POST,'IDUSUARIO',FILTER_DEFAULT));
$Login = filter_input(INPUT_POST,'LOGIN',FILTER_DEFAULT);
$Senha = filter_input(INPUT_POST,'SENHA',FILTER_DEFAULT);
$idbarbeiro = filter_input(INPUT_POST,'IDBARBEIRO',FILTER_DEFAULT);
/*esses campos vão mudar, lembre-se*/
$sql = "UPDATE USUARIOS (LOGIN,SENHA,IDBARBEIRO)
        VALUES (?,?,? ) 
        WHERE IDUSUARIO=? ";        

$rs = mysqli_prepare($banco,$sql);
                                            
mysqli_stmt_bind_param($rs,'sss', $Login ,$Senha, $idbarbeiro) ;                                            
mysqli_stmt_execute($rs);
header('location:index.php');
